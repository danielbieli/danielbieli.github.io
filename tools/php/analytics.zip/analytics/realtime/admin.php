<!DOCTYPE html>
	<html lang="en">
   	 	<head>
   	 		<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
			<meta content="utf-8" http-equiv="encoding">
   	 		<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600' rel='stylesheet' type='text/css'>
			<link href="style.css" rel="stylesheet" type="text/css" />
    	</head>
    	<body class="body">
    		<div class="content">
				<div class="content_holder" id="content_holder">
				</div>
			</div>
			<script src="admin.js" language="javascript" type="text/javascript"></script>
		</body>
	</html>