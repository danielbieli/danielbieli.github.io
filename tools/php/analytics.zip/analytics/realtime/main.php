<?php

	// Timezone
	
	$timezone = 'Australia/Melbourne';
	
	
	// Analytics Folder
	
	$analytics_folder = '../analytics';
?>