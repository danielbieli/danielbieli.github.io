<?php
	// Password for Admin Login
	
	$admin_password = 'Dan!el1992';

	// Your Timezone - Only use valid PHP timezones!!!
	
	$timezone = 'Europe/Zurich';
	

	// Optional

	// Name of Folder where analytics are stored
	
	$analytics_folder = 'analytics';
?>